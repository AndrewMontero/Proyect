package Controller;

import Model.DAOCandidatos;
import Model.Candidatos;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.List;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author SeniorPaulol
 */

public class CtrlGrafico {

    DAOCandidatos dao = new DAOCandidatos();

   
    public DefaultCategoryDataset graficoResultados() {
        DefaultCategoryDataset data = new DefaultCategoryDataset();
        List<Candidatos> candidate1 = this.dao.readCandidates();
        for (Candidatos candidate : candidate1) {
            int vote = (int) candidate.getVotos();
            String name = candidate.getNombre();
            String party = candidate.getPartido();
            data.setValue(vote, name, party);
        }
        return data;
    }

  
    public void addGraph(JPanel jPanel5, DefaultCategoryDataset data) {
    
        JFreeChart graph = ChartFactory.createBarChart("--Grafico Votos-", "Nombres ", "Votos", data, PlotOrientation.VERTICAL, true, true, false);
      
        ChartPanel panel = new ChartPanel(graph);
        panel.setMouseWheelEnabled(true);
        panel.setPreferredSize(new Dimension(1158, 494));
        jPanel5.setLayout(new BorderLayout());
        jPanel5.add(panel, BorderLayout.NORTH);
    }

}
