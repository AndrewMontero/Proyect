package Controller;

import Model.Rol;
import Model.DAORol;
import Model.Usuario;
import Model.DAOUsuario;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author SeniorPaulol
 */

public class CtrlUsuario {

    DAOUsuario ud = new DAOUsuario();
    DAORol rd = new DAORol();
    int id;
    int RoleID;

    
    public void loadDataUser(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        TableRowSorter<TableModel> order = new TableRowSorter<TableModel>(model);
        table.setRowSorter(order);
        model.setRowCount(0);

        List<Usuario> users = ud.read();// Load all users
        for (Usuario user : users) {
            Object[] row = {
                user.getId(),
                user.getNombre(),
                user.getApellido(),
                user.getSegundo_apellido(),
                user.getCedula(),
                user.getEdad(),
                user.getDireccion(),
                user.getContrasena(),
                user.getRol_id()
            };
            model.addRow(row);
        }
    }

    public void addUser(JTextField name, JTextField last_name, JTextField secund_name, JTextField id_number, JComboBox age, JTextField address, JTextField password, JComboBox rol_id) {
        if (name.getText().isEmpty() || last_name.getText().isEmpty() || id_number.getText().isEmpty() || age.getSelectedItem() == null || address.getText().isEmpty() || password.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }

        try {
            
            Integer.parseInt(id_number.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La identificación debe ser números enteros", "Error", JOptionPane.ERROR_MESSAGE);
            return;  
        }

        
        if (!name.getText().matches("^[a-z A-ZáéíóúÁÉÍÓÚñÑ]+$") || !last_name.getText().matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+$") || !secund_name.getText().matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+$")) {
            JOptionPane.showMessageDialog(null, "El nombre y apellidos deben contener solo letras", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }

        this.ud.create(new Usuario(name.getText(), last_name.getText(), secund_name.getText(), Integer.parseInt(id_number.getText()), Integer.parseInt(age.getSelectedItem().toString()), address.getText(), password.getText(), rol_id.getSelectedItem().toString()));
        this.ud.reorganizarIDs();

    }

    public void upDatauSERS(JTextField txtNameVot, JTextField txtLastNameVot, JTextField txtSecundNameVot, JTextField txtIdentificationVot, JComboBox cbxAgeVot, JTextField txtAddressVot, JTextField txtPasswordVot, JComboBox rol_id) {
        if (txtNameVot.getText().isEmpty() || txtLastNameVot.getText().isEmpty() || txtIdentificationVot.getText().isEmpty() || cbxAgeVot.getSelectedItem() == null || txtAddressVot.getText().isEmpty() || txtPasswordVot.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }

        try {
           
            Integer.parseInt(txtIdentificationVot.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "La identificación debe ser un número entero", "Error", JOptionPane.ERROR_MESSAGE);
            return;  
        }

       
        if (!txtNameVot.getText().matches("^[a-z A-ZáéíóúÁÉÍÓÚñÑ]+$") || !txtLastNameVot.getText().matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+$") || !txtSecundNameVot.getText().matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ]+$")) {
            JOptionPane.showMessageDialog(null, "El nombre y apellidos deben contener solo letras", "Error", JOptionPane.ERROR_MESSAGE);
            return;  
        }

        this.ud.update(new Usuario(id, txtNameVot.getText(), txtLastNameVot.getText(), txtSecundNameVot.getText(), Integer.parseInt(txtIdentificationVot.getText()), Integer.parseInt(cbxAgeVot.getSelectedItem().toString()), txtAddressVot.getText(), txtPasswordVot.getText(), rol_id.getSelectedItem().toString()));
        this.ud.reorganizarIDs();

    }

    public void deleteUser() {
        this.ud.delete(this.id);
        this.ud.reorganizarIDs();
    }

    public void selectedRow(JTable table, JTextField name, JTextField last_name, JTextField secund_name, JTextField id_number, JComboBox age, JTextField address, JTextField password, JComboBox rol_id) {
        try {
            int row = table.getSelectedRow();
            if (row >= 0) {
                this.id = Integer.parseInt(table.getValueAt(row, 0).toString());
                name.setText((table.getValueAt(row, 1).toString()));
                last_name.setText((table.getValueAt(row, 2).toString()));
                secund_name.setText((table.getValueAt(row, 3).toString()));
                id_number.setText((table.getValueAt(row, 4).toString()));
                age.setSelectedItem(table.getValueAt(row, 5).toString());
                address.setText(table.getValueAt(row, 6).toString());
                password.setText((table.getValueAt(row, 7).toString()));
                rol_id.setSelectedItem((table.getValueAt(row, 8).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error de seleccion, error: " + e.toString());

            System.out.println(e.toString());
        }
    }

    
    public void clearFields(JTextField name, JTextField last_name, JTextField secund_name, JTextField id_number, JTextField address, JTextField password) {
        name.setText("");
        last_name.setText("");
        secund_name.setText("");
        id_number.setText("");
        address.setText("");
        password.setText("");
    }

     
    public void getIdRole(JComboBox role) {
        this.RoleID = this.rd.getIDRole(role.getSelectedItem().toString());
    }

    
    public void loadRole(JComboBox c, boolean isAdmin, boolean isVotante) {
        List<Rol> roles = this.rd.read();
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();

        for (Rol role : roles) {
            if ((isAdmin && (role.getNombre().equals("Administrador") || role.getNombre().equals("Votante")))
                    || (isVotante && role.getNombre().equals("Votante"))
                    || (!isAdmin && !isVotante)) {
                model.addElement(role.getNombre());
            }
        }

        c.setModel(model);
    }

}
