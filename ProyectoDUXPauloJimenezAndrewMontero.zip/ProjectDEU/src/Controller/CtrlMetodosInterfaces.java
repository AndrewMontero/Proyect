package Controller;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

/**
 *
 * @author SeniorPaulol
 */
public class CtrlMetodosInterfaces {

    
    public void AnadirBorde(JLabel lbl) {
        lbl.setOpaque(true);
        lbl.setBackground(new Color(0, 0, 102));
        lbl.setForeground(Color.white);
        Border borde = new LineBorder(Color.BLUE, 1);
        lbl.setBorder(borde);
    }

    public void bordeNull(JLabel lbl) {
        lbl.setForeground(Color.black);
        lbl.setOpaque(false); 
        lbl.setBorder(null);
    }

}
