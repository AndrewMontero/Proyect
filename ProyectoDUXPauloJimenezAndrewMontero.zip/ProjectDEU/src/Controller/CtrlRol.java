package Controller;

import Model.DAORol;
import Model.DAOUsuario;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author SeniorPaulol
 */

public class CtrlRol {

    DAORol dao = new DAORol();
    DAOUsuario UD = new DAOUsuario();

    public void entrar_Interfaz(String id_NUmber, String password, JFrame user, JFrame adm) {
        this.UD.getUserByUsername(id_NUmber);
        String role = this.dao.determineRole(id_NUmber, password);
        if ("Votante".equals(role)) {
            user.setVisible(true);
        } else if ("Admin".equals(role)) {
            adm.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "Datos ingresados Incorrectos");
        }
    }

}
