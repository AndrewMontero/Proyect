package Model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Andrew
 */
public class DAORol {

    public DAORol() {
    }

    // Retrieve a list of all roles from the database.
    public List<Rol> read() {

        DBConnection db = new DBConnection();
        List<Rol> Roles = new ArrayList<>();
        String sql = "SELECT * FROM roles";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("nombre");
                Roles.add(new Rol(id, name));
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return Roles;
    }

    //Retrieve the ID of a role based on its name.
    public int getIDRole(String name) {
        int value = 0;
        DBConnection db = new DBConnection();
        String sql = "SELECT id FROM roles WHERE nombre = ?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, name);
            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                value = resultSet.getInt("id");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return value;
    }

    // Retrieve the name of a role based on its ID.
    public String getNameRole(int id) {
        String value = "";
        DBConnection db = new DBConnection();
        String sql = "SELECT nombre FROM roles WHERE id = ?";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                value = resultSet.getString("nombre");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return value;
    }

    // Determines the role of a user based on their ID number and password.
    public String determineRole(String user, String pasword) {
        DBConnection db = new DBConnection();
        String rol = "";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("SELECT rol_id FROM users WHERE cedula = ? AND contrasena = ?");
            ps.setString(1, user);
            ps.setString(2, pasword);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                rol = resultSet.getString("rol_id");
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return rol;
    }
}
