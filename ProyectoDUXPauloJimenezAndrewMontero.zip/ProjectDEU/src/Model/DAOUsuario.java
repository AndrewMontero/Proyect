package Model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author SeniorPaulol
 */

public class DAOUsuario {

    public DAOUsuario() {
    }

    /*Creates a new user record in the database.
     The User object containing user information to be inserted.*/
    public void create(Usuario User) {

        DBConnection db = new DBConnection();
        String consultaSQL = "INSERT INTO users (nombre,apellido, segundo_apellido, cedula, edad, direccion, contrasena, rol_id ) VALUES (?, ?, ?, ?,?,?,?,?)";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(consultaSQL);
            ps.setString(1, User.getNombre());
            ps.setString(2, User.getApellido());
            ps.setString(3, User.getSegundo_apellido());
            ps.setInt(4, User.getCedula());
            ps.setInt(5, User.getEdad());
            ps.setString(6, User.getDireccion());
            ps.setString(7, User.getContrasena());
            ps.setString(8, User.getRol_id());
            ps.execute();
            JOptionPane.showMessageDialog(null, "Se insertó correctamente el usuario ");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se insertó correctamente el usuario, error: " + e.toString());
        } finally {
            db.disconnect();
        }
    }

    public List<Usuario> read() {

        DBConnection db = new DBConnection();
        List<Usuario> Users = new ArrayList<>();
        String sql = "SELECT * FROM users";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("nombre");
                String last_name = resultSet.getString("apellido");
                String second_name = resultSet.getString("segundo_apellido");
                int id_number = resultSet.getInt("cedula");
                int age = resultSet.getInt("edad");
                String address = resultSet.getString("direccion");
                String password = resultSet.getString("contrasena");
                String rol_id = resultSet.getString("rol_id");
                int Estado = resultSet.getInt("Estado");
                Users.add(new Usuario(id, name, last_name, second_name, id_number, age, address, password, rol_id, Estado));
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return Users;
    }

    //Updates user information in the database based on the provided User object.
    public void update(Usuario User) {

        DBConnection db = new DBConnection();
        String consultaSQL = "UPDATE users SET nombre=?, apellido=?, segundo_apellido=?, cedula=?, edad=?, direccion=?, contrasena=?, rol_id=? WHERE id=?";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(consultaSQL);
            ps.setString(1, User.getNombre());
            ps.setString(2, User.getApellido());
            ps.setString(3, User.getSegundo_apellido());
            ps.setInt(4, User.getCedula());
            ps.setInt(5, User.getEdad());
            ps.setString(6, User.getDireccion());
            ps.setString(7, User.getContrasena());
            ps.setString(8, User.getRol_id());
            ps.setInt(9, User.getId());
            ps.executeUpdate();  // Utiliza executeUpdate en lugar de execute para sentencias de actualización.

            JOptionPane.showMessageDialog(null, "Modificación Exitosa");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se modificó, error:" + e.toString());
        } finally {
            db.disconnect();
        }
    }

    //Deletes a user from the database based on the provided user ID.
    public void delete(int id) {

        DBConnection db = new DBConnection();

        String consultaSQL = "DELETE FROM users WHERE id=?";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(consultaSQL);
            ps.setInt(1, id);
            ps.execute();
            JOptionPane.showMessageDialog(null, "Se eliminó correctamente el usuario ");

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
        } finally {
            db.disconnect();
        }
    }

    public void reorganizarIDs() {
        DBConnection db = new DBConnection();

        // Consulta SQL para obtener todos los IDs de los estudiantes ordenados
        String consultaSQL = "SELECT id FROM users ORDER BY id";
        try (PreparedStatement preparedStatement = db.getConnection().prepareStatement(consultaSQL); ResultSet resultSet = preparedStatement.executeQuery()) {

            int nuevoID = 1;
            while (resultSet.next()) {
                int antiguoID = resultSet.getInt("id");
                if (nuevoID != antiguoID) {
                    try (PreparedStatement updateStatement = db.getConnection().prepareStatement("UPDATE users SET id = ? WHERE id = ?")) {
                        updateStatement.setInt(1, nuevoID);
                        updateStatement.setInt(2, antiguoID);
                        updateStatement.executeUpdate();
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "Error al actualizar el ID: " + e.toString());
                    }
                }
                nuevoID++;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener los IDs: " + e.toString());
        } finally {
            db.disconnect();
        }
    }

    //Retrieves a User object from the database based on the provided username.
    public Usuario getUserByUsername(String id_NUmber) {
        DBConnection db = new DBConnection();
        Usuario user = null;
        String sql = "SELECT * FROM users WHERE cedula = ?";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ps.setString(1, id_NUmber);
            ResultSet resultSet = ps.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("nombre");
                String last_name = resultSet.getString("apellido");
                String second_name = resultSet.getString("segundo_apellido");
                int id_number = resultSet.getInt("cedula");
                int age = resultSet.getInt("edad");
                String address = resultSet.getString("direccion");
                String password = resultSet.getString("contrasena");
                String rol_id = resultSet.getString("rol_id");
                int Estado = resultSet.getInt("Estado");
                user = new Usuario(id, name, last_name, second_name, id_number, age, address, password, rol_id, Estado);
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }

        return user;
    }

    // Method to update the state of a user to 1 based on the user ID
    public void updateStateTo1(String userId) {
        DBConnection db = new DBConnection();
        String updateSQL = "UPDATE users SET Estado = 1 WHERE cedula = ?";

        try {
            PreparedStatement ps = db.getConnection().prepareStatement(updateSQL);
            ps.setString(1, userId);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Estado actualizado correctamente");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el estado: " + e.toString());
        } finally {
            db.disconnect();
        }
    }
}
