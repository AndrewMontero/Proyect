package Model;

/**
 *
 * @author SeniorPaulol
 */

public class Candidatos {

    private int id;
    private String nombre;
    private String apellido;
    private String segundo_apellido;
    private int cedula;
    private int edad;
    private byte[] foto;
    private String partido;
    private int votos;

   public Candidatos(int id, String nombre, String apellido, String segundo_apellido, int cedula, int edad, byte[] foto, String partido, int votos) {
    this.id = id;
    this.nombre = nombre;
    this.apellido = apellido;
    this.segundo_apellido = segundo_apellido;
    this.cedula = cedula;
    this.edad = edad;
    this.foto = foto;
    this.partido = partido;
    this.votos = votos;
}

public Candidatos(String nombre, String apellido, String segundo_apellido, int cedula, int edad, byte[] foto, String partido) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.segundo_apellido = segundo_apellido;
    this.cedula = cedula;
    this.edad = edad;
    this.foto = foto;
    this.partido = partido;
}

public Candidatos(int id, String nombre, String apellido, String segundo_apellido, int cedula, int edad, byte[] foto, String partido) {
    this.id = id;
    this.nombre = nombre;
    this.apellido = apellido;
    this.segundo_apellido = segundo_apellido;
    this.cedula = cedula;
    this.edad = edad;
    this.foto = foto;
    this.partido = partido;
}

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the name to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the last_name
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the last_name to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the second_name
     */
    public String getSegundo_apellido() {
        return segundo_apellido;
    }

    /**
     * @param segundo_apellido the second_name to set
     */
    public void setSegundo_apellido(String segundo_apellido) {
        this.segundo_apellido = segundo_apellido;
    }

    /**
     * @return the id_number
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @param cedula the id_number to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the age
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the age to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * @return the photo
     */
    public byte[] getFoto() {
        return foto;
    }

    /**
     * @param foto the photo to set
     */
    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

    /**
     * @return the party
     */
    public String getPartido() {
        return partido;
    }

    /**
     * @param partido the party to set
     */
    public void setPartido(String partido) {
        this.partido = partido;
    }

    /**
     * @return the votes
     */
    public int getVotos() {
        return votos;
    }

    /**
     * @param votos the votes to set
     */
    public void setVotos(int votos) {
        this.votos = votos;
    }

}
