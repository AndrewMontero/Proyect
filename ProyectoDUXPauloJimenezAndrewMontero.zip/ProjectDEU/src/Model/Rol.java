package Model;

/**
 *
 * @author SeniorSlow
 */

public class Rol {

    private int id;
    private String nombre;

    public Rol() {
    }

    public Rol(String name) {
        this.nombre = name;

    }

    public Rol(int id, String name) {
        this.id = id;
        this.nombre = name;

    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the name to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}
