package Model;

/**
 *
 * @author Andrew
 */

public class Usuario {

    private int id;
    private String nombre, apellido, segundo_apellido;
    private int cedula, edad;
    private String direccion, contrasena, rol_id;
    private int Estado;

    public Usuario(int id, String nombre, String apellido, String segundo_apellido, int cedula, int edad, String direccion, String contrasena, String rol_id) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.segundo_apellido = segundo_apellido;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.contrasena = contrasena;
        this.rol_id = rol_id;
    }

    public Usuario(int id, String nombre, String apellido, String segundo_apellido, int cedula, int edad, String direccion, String contrasena, String rol_id, int Estado) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.segundo_apellido = segundo_apellido;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.contrasena = contrasena;
        this.rol_id = rol_id;
        this.Estado = Estado;
    }

    public Usuario(String nombre, String apellido, String segundo_apellido, int cedula, int edad, String direccion, String contrasena, String rol_id) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.segundo_apellido = segundo_apellido;
        this.cedula = cedula;
        this.edad = edad;
        this.direccion = direccion;
        this.contrasena = contrasena;
        this.rol_id = rol_id;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the name to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the last_name
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * @param apellido the last_name to set
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * @return the secund_name
     */
    public String getSegundo_apellido() {
        return segundo_apellido;
    }

    /**
     * @param segundo_apellido the secund_name to set
     */
    public void setSegundo_apellido(String segundo_apellido) {
        this.segundo_apellido = segundo_apellido;
    }

    /**
     * @return the id_number
     */
    public int getCedula() {
        return cedula;
    }

    /**
     * @param cedula the id_number to set
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * @return the age
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the age to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * @return the address
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * @param direccion the address to set
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return the password
     */
    public String getContrasena() {
        return contrasena;
    }

    /**
     * @param contrasena the password to set
     */
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    /**
     * @return the rol_id
     */
    public String getRol_id() {
        return rol_id;
    }

    /**
     * @param rol_id the rol_id to set
     */
    public void setRol_id(String rol_id) {
        this.rol_id = rol_id;
    }

    /**
     * @return the Estado
     */
    public int getEstado() {
        return Estado;
    }

    /**
     * @param Estado the Estado to set
     */
    public void setEstado(int Estado) {
        this.Estado = Estado;
    }

}
