package Model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Andrew
 */
public class DAOCandidatos {

    public void crearCandidato(Candidatos cand) {
        DBConnection db = new DBConnection();
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("INSERT INTO candidatos (nombre,apellido,segundo_apellido,edad,foto,partido,votos,cedula) VALUES(?,?,?,?,?,?,?,?)");
            ps.setString(1, cand.getNombre());
            ps.setString(2, cand.getApellido());
            ps.setString(3, cand.getSegundo_apellido());
            ps.setInt(4, cand.getEdad());
            ps.setBytes(5, cand.getFoto()); // Save the photo as bytes
            ps.setString(6, cand.getPartido());
            ps.setInt(7, cand.getVotos());
            ps.setInt(8, cand.getCedula());
            ps.execute();
            JOptionPane.showMessageDialog(null, "Se insertó correctamente el candidato");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se insertó correctamente el candidato, error: " + e.toString());
        } finally {
            db.disconnect();
        }
    }

    public byte[] bitesPhoto(int id) {
        DBConnection db = new DBConnection();
        byte[] photoBytes = null;
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("SELECT foto FROM candidatos WHERE id = ?");
            ps.setInt(1, id);

            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                photoBytes = resultSet.getBytes("foto");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron datos para el candidato con ID: " + id);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la foto del candidato, error: " + e.toString());
        } finally {
            db.disconnect();
        }
        return photoBytes;
    }

    public byte[] returnPhoto(String name) {
        DBConnection db = new DBConnection();
        byte[] photoBytes = null;
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("SELECT foto FROM candidatos WHERE id = (SELECT id FROM candidatos WHERE nombre =?)");
            ps.setString(1, name);

            ResultSet resultSet = ps.executeQuery();
            if (resultSet.next()) {
                photoBytes = resultSet.getBytes("foto");
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron datos para el candidato ");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener la foto del candidato, error: " + e.toString());
        } finally {
            db.disconnect();
        }
        return photoBytes;
    }

    public void upCandidates(Candidatos cand) {
        DBConnection db = new DBConnection();
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("UPDATE candidatos SET  nombre=?, apellido=?, segundo_apellido=?,edad=?,foto=?,partido=?,cedula=? WHERE id=?");
            ps.setString(1, cand.getNombre());
            ps.setString(2, cand.getApellido());
            ps.setString(3, cand.getSegundo_apellido());
            ps.setInt(4, cand.getEdad());
            ps.setBytes(5, cand.getFoto());
            ps.setString(6, cand.getPartido());
            ps.setInt(7, cand.getCedula());
            ps.setInt(8, cand.getId());
            ps.execute();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se insertó correctamente el candidato, error: " + e.toString());
            System.err.println(e);
        } finally {
            db.disconnect();
        }
    }

    public List<Candidatos> readCandidates() {
        DBConnection db = new DBConnection();
        List<Candidatos> cnadidates = new ArrayList<>();
        String sql = "SELECT * FROM candidatos";
        try {
            PreparedStatement ps = db.getConnection().prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("nombre");
                String last_Name = resultSet.getString("apellido");
                String second_Name = resultSet.getString("segundo_apellido");
                int age = resultSet.getInt("edad");
                byte[] photo = resultSet.getBytes("foto");
                String party = resultSet.getString("partido");
                int vote = resultSet.getInt("votos");
                int id_number = resultSet.getInt("cedula");
                cnadidates.add(new Candidatos(id, name, last_Name, second_Name, id_number, age, photo, party, vote));
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return cnadidates;
    }

    public void delete(int id) {
        DBConnection db = new DBConnection();
        try {
            PreparedStatement ps = db.getConnection().prepareStatement("DELETE FROM candidatos WHERE id=?");
            ps.setInt(1, id);
            ps.execute();
            JOptionPane.showMessageDialog(null, "Se eliminó correctamente");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo eliminar, error: " + e.toString());
        } finally {
            db.disconnect();
        }
    }

    public List<Candidatos> QuantityVoteCandidate(String name) {
        DBConnection db = new DBConnection();
        List<Candidatos> candidatesList = new ArrayList<>();
        String selectSql = "SELECT votos  FROM candidatos WHERE nombre =?";
        String insertSql = "UPDATE  candidatos set votos=? WHERE nombre=?";
        try {
            PreparedStatement selectStatement = db.getConnection().prepareStatement(selectSql);
            selectStatement.setString(1, name);
            ResultSet resultSet = selectStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("votos");
                try (PreparedStatement insertStatement = db.getConnection().prepareStatement(insertSql)) {
                    id += 1;
                    insertStatement.setInt(1, id);
                    insertStatement.setString(2, name);
                    insertStatement.executeUpdate();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            db.disconnect();
        }
        return candidatesList;
    }

    public void reorganizarIDsCan() {
        DBConnection db = new DBConnection();

        String consultaSQL = "SELECT id FROM candidatos ORDER BY id";
        try (PreparedStatement preparedStatement = db.getConnection().prepareStatement(consultaSQL); ResultSet resultSet = preparedStatement.executeQuery()) {

            int nuevoID = 1;
            while (resultSet.next()) {
                int antiguoID = resultSet.getInt("id");
                if (nuevoID != antiguoID) {
                    try (PreparedStatement updateStatement = db.getConnection().prepareStatement("UPDATE candidatos SET id = ? WHERE id = ?")) {
                        updateStatement.setInt(1, nuevoID);
                        updateStatement.setInt(2, antiguoID);
                        updateStatement.executeUpdate();
                    } catch (SQLException e) {
                        JOptionPane.showMessageDialog(null, "Error al actualizar el ID: " + e.toString());
                    }
                }
                nuevoID++;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener los IDs: " + e.toString());
        } finally {
            db.disconnect();
        }
    }
}
